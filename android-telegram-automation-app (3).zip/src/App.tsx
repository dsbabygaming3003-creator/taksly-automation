import { useState } from "react";

type SourceFile = {
  path: string;
  content: string;
};

const sourceFiles: SourceFile[] = [
  {
    path: "settings.gradle.kts",
    content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "TakslyAutomation"
include(":app")`,
  },
  {
    path: "build.gradle.kts (Project)",
    content: `plugins {
    id("com.android.application") version "8.6.1" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false
}`,
  },
  {
    path: "app/build.gradle.kts",
    content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.takslyautomation"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.takslyautomation"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}`,
  },
  {
    path: "app/src/main/AndroidManifest.xml",
    content: `<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.example.takslyautomation">

    <queries>
        <package android:name="org.telegram.messenger" />
    </queries>

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="Taksly Automation"
        android:supportsRtl="true"
        android:theme="@style/Theme.Material3.DayNight.NoActionBar">

        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <service
            android:name=".TelegramAutomationService"
            android:exported="false"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>

            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>
    </application>
</manifest>`,
  },
  {
    path: "app/src/main/java/com/example/takslyautomation/MainActivity.kt",
    content: `package com.example.takslyautomation

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.openAccessibilityButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.openTelegramButton).setOnClickListener {
            openTelegram()
        }
    }

    override fun onResume() {
        super.onResume()
        val statusText = findViewById<TextView>(R.id.statusText)
        statusText.text = if (isServiceEnabled()) {
            "Accessibility service is ON. Opening Telegram..."
        } else {
            "Turn ON Taksly Automation in Accessibility settings, then return here."
        }
        openTelegram()
    }

    private fun openTelegram() {
        val launchIntent = packageManager.getLaunchIntentForPackage("org.telegram.messenger")
        launchIntent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        launchIntent?.let { startActivity(it) }
    }

    private fun isServiceEnabled(): Boolean {
        val manager = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = manager.getEnabledAccessibilityServiceList(
            AccessibilityServiceInfo.FEEDBACK_GENERIC
        )

        return enabledServices.any { serviceInfo ->
            serviceInfo.resolveInfo.serviceInfo.packageName == packageName &&
                serviceInfo.resolveInfo.serviceInfo.name == TelegramAutomationService::class.java.name
        }
    }
}`,
  },
  {
    path: "app/src/main/java/com/example/takslyautomation/TelegramAutomationService.kt",
    content: `package com.example.takslyautomation

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class TelegramAutomationService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())

    private enum class Step {
        OPEN_BOT,
        CLICK_TASKS,
        CLICK_CREATE_INST,
        CLICK_START,
        DONE
    }

    private var currentStep = Step.OPEN_BOT
    private var lastActionAt = 0L

    override fun onServiceConnected() {
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 150
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName?.toString() != "org.telegram.messenger") return
        val now = System.currentTimeMillis()
        if (now - lastActionAt < 900) return

        val root = rootInActiveWindow ?: return
        when (currentStep) {
            Step.OPEN_BOT -> {
                if (clickTextContains(root, "Taksly Bot")) {
                    currentStep = Step.CLICK_TASKS
                    markAction()
                } else {
                    scrollChatList(root)
                }
            }

            Step.CLICK_TASKS -> {
                if (clickTextEquals(root, "Tasks")) {
                    currentStep = Step.CLICK_CREATE_INST
                    markAction()
                }
            }

            Step.CLICK_CREATE_INST -> {
                if (clickTextEquals(root, "Create Inst (2FA)")) {
                    currentStep = Step.CLICK_START
                    markAction()
                }
            }

            Step.CLICK_START -> {
                if (clickTextEquals(root, "Start")) {
                    currentStep = Step.DONE
                    markAction()
                }
            }

            Step.DONE -> Unit
        }
    }

    override fun onInterrupt() = Unit

    private fun markAction() {
        lastActionAt = System.currentTimeMillis()
    }

    private fun clickTextContains(root: AccessibilityNodeInfo, text: String): Boolean {
        val nodes = root.findAccessibilityNodeInfosByText(text)
        val target = nodes.firstOrNull { node ->
            node.text?.toString()?.contains(text, ignoreCase = true) == true
        } ?: return false
        return performClick(target)
    }

    private fun clickTextEquals(root: AccessibilityNodeInfo, text: String): Boolean {
        val nodes = root.findAccessibilityNodeInfosByText(text)
        val target = nodes.firstOrNull { node ->
            node.text?.toString()?.trim()?.equals(text, ignoreCase = true) == true
        } ?: return false
        return performClick(target)
    }

    private fun performClick(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
        }
        return false
    }

    private fun scrollChatList(root: AccessibilityNodeInfo) {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)

        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            if (node.isScrollable) {
                node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
                markAction()
                return
            }
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let(queue::add)
            }
        }
    }
}`,
  },
  {
    path: "app/src/main/res/xml/accessibility_service_config.xml",
    content: `<?xml version="1.0" encoding="utf-8"?>
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:accessibilityEventTypes="typeWindowStateChanged|typeWindowContentChanged"
    android:accessibilityFeedbackType="feedbackGeneric"
    android:notificationTimeout="150"
    android:canRetrieveWindowContent="true"
    android:canPerformGestures="false"
    android:description="@string/accessibility_description"
    android:settingsActivity=""
    android:accessibilityFlags="flagReportViewIds|flagRetrieveInteractiveWindows" />`,
  },
  {
    path: "app/src/main/res/layout/activity_main.xml",
    content: `<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="24dp">

    <TextView
        android:id="@+id/titleText"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="Taksly Telegram Automation"
        android:textSize="24sp"
        android:textStyle="bold" />

    <TextView
        android:id="@+id/statusText"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="12dp"
        android:text="Checking service status..."
        android:textSize="15sp" />

    <Button
        android:id="@+id/openAccessibilityButton"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="20dp"
        android:text="Open Accessibility Settings" />

    <Button
        android:id="@+id/openTelegramButton"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="12dp"
        android:text="Open Telegram Now" />
</LinearLayout>`,
  },
  {
    path: "app/src/main/res/values/strings.xml",
    content: `<resources>
    <string name="app_name">Taksly Automation</string>
    <string name="accessibility_description">
        Automates Telegram steps for Taksly Bot: Tasks -> Create Inst (2FA) -> Start.
    </string>
</resources>`,
  },
];

const buildSteps = [
  "Install Android Studio (Koala or newer) and Android SDK 35.",
  "Create a new Empty Activity project named TakslyAutomation with Kotlin.",
  "Replace generated files with the source shown below using the same paths.",
  "Open Tools -> SDK Manager and ensure Android 14/15 platform and Build-Tools are installed.",
  "Sync Gradle, then Build -> Build Bundle(s) / APK(s) -> Build APK(s).",
  "Install APK on your Android device.",
  "Open the app, tap Open Accessibility Settings, enable Taksly Automation service, return to app.",
  "Telegram opens automatically and automation runs in sequence: Taksly Bot -> Tasks -> Create Inst (2FA) -> Start.",
];

export default function App() {
  const [copiedPath, setCopiedPath] = useState<string | null>(null);

  const copyToClipboard = async (text: string, path: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedPath(path);
    window.setTimeout(() => setCopiedPath(null), 1400);
  };

  return (
    <div className="bg-slate-950 text-slate-100">
      <style>{`
        @keyframes slowZoom {
          0% { transform: scale(1); }
          100% { transform: scale(1.08); }
        }
        @keyframes riseIn {
          0% { opacity: 0; transform: translateY(20px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        @keyframes bob {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(6px); }
        }
      `}</style>

      <section className="relative min-h-screen overflow-hidden">
        <img
          src="/images/telegram-automation-hero.jpg"
          alt="Android phone with Telegram open"
          className="absolute inset-0 h-full w-full object-cover opacity-35"
          style={{ animation: "slowZoom 16s ease-in-out infinite alternate" }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950/65 via-slate-950/70 to-slate-950" />

        <div className="relative mx-auto flex min-h-screen w-full max-w-6xl flex-col justify-center px-6 py-20 lg:px-10">
          <p
            className="text-sm tracking-[0.24em] text-cyan-300"
            style={{ animation: "riseIn 700ms ease-out both" }}
          >
            TAKSLY AUTOMATION APK SOURCE
          </p>
          <h1
            className="mt-4 max-w-4xl text-4xl font-semibold leading-tight text-white md:text-6xl"
            style={{ animation: "riseIn 900ms ease-out 120ms both" }}
          >
            Complete Android Accessibility automation for Telegram bot flow.
          </h1>
          <p
            className="mt-6 max-w-2xl text-base leading-relaxed text-slate-200 md:text-lg"
            style={{ animation: "riseIn 1100ms ease-out 220ms both" }}
          >
            This implementation launches Telegram, opens Taksly Bot, clicks Tasks, selects Create Inst
            (2FA), and presses Start in sequence.
          </p>
          <a
            href="#source"
            className="mt-10 inline-flex w-fit items-center border border-cyan-300/50 bg-cyan-400/10 px-6 py-3 text-sm font-medium text-cyan-100 transition hover:bg-cyan-400/20"
            style={{ animation: "riseIn 1200ms ease-out 300ms both" }}
          >
            Jump To Full Source
          </a>
          <div className="mt-10 text-cyan-200" style={{ animation: "bob 1.8s ease-in-out infinite" }}>
            Scroll for all files and build steps
          </div>
        </div>
      </section>

      <section className="mx-auto w-full max-w-6xl px-6 py-16 lg:px-10" id="source">
        <h2 className="text-2xl font-semibold text-white md:text-3xl">Implementation Files</h2>
        <p className="mt-3 max-w-3xl text-slate-300">
          Create an Android project, then replace each file with the exact code below.
        </p>

        <div className="mt-10 space-y-8">
          {sourceFiles.map((file) => (
            <article key={file.path} className="border border-slate-800 bg-slate-900/60">
              <div className="flex items-center justify-between border-b border-slate-800 px-4 py-3">
                <h3 className="font-mono text-sm text-cyan-200">{file.path}</h3>
                <button
                  onClick={() => copyToClipboard(file.content, file.path)}
                  className="border border-slate-600 px-3 py-1 text-xs text-slate-200 transition hover:border-cyan-300 hover:text-cyan-200"
                >
                  {copiedPath === file.path ? "Copied" : "Copy"}
                </button>
              </div>
              <pre className="overflow-x-auto p-4 text-xs leading-relaxed text-slate-100">
                <code>{file.content}</code>
              </pre>
            </article>
          ))}
        </div>
      </section>

      <section className="border-t border-slate-800 bg-slate-900/50">
        <div className="mx-auto w-full max-w-6xl px-6 py-16 lg:px-10">
          <h2 className="text-2xl font-semibold text-white md:text-3xl">Build APK Steps</h2>
          <ol className="mt-6 space-y-4 text-slate-200">
            {buildSteps.map((step, index) => (
              <li key={step} className="flex gap-3">
                <span className="text-cyan-300">{index + 1}.</span>
                <span>{step}</span>
              </li>
            ))}
          </ol>

          <p className="mt-8 text-sm text-slate-400">
            Note: Telegram UI can change by version and language. Keep Telegram language in English and
            place Taksly Bot in visible chats for highest reliability.
          </p>
        </div>
      </section>
    </div>
  );
}
