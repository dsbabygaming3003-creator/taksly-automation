package com.example.takslyautomation

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class TelegramAutomationService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())

    private enum class Step {
        OPEN_BOT,
        CLICK_TASKS,
        CLICK_CREATE_INST,
        CLICK_START,
        DONE
    }

    private var currentStep = Step.OPEN_BOT
    private var lastActionAt = 0L

    override fun onServiceConnected() {
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 150
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName?.toString() != "org.telegram.messenger") return
        val now = System.currentTimeMillis()
        if (now - lastActionAt < 900) return

        val root = rootInActiveWindow ?: return
        when (currentStep) {
            Step.OPEN_BOT -> {
                if (clickTextContains(root, "Taksly Bot")) {
                    currentStep = Step.CLICK_TASKS
                    markAction()
                } else {
                    scrollChatList(root)
                }
            }

            Step.CLICK_TASKS -> {
                if (clickTextEquals(root, "Tasks")) {
                    currentStep = Step.CLICK_CREATE_INST
                    markAction()
                }
            }

            Step.CLICK_CREATE_INST -> {
                if (clickTextEquals(root, "Create Inst (2FA)")) {
                    currentStep = Step.CLICK_START
                    markAction()
                }
            }

            Step.CLICK_START -> {
                if (clickTextEquals(root, "Start")) {
                    currentStep = Step.DONE
                    markAction()
                }
            }

            Step.DONE -> Unit
        }
    }

    override fun onInterrupt() = Unit

    private fun markAction() {
        lastActionAt = System.currentTimeMillis()
    }

    private fun clickTextContains(root: AccessibilityNodeInfo, text: String): Boolean {
        val nodes = root.findAccessibilityNodeInfosByText(text)
        val target = nodes.firstOrNull { node ->
            node.text?.toString()?.contains(text, ignoreCase = true) == true
        } ?: return false
        return performClick(target)
    }

    private fun clickTextEquals(root: AccessibilityNodeInfo, text: String): Boolean {
        val nodes = root.findAccessibilityNodeInfosByText(text)
        val target = nodes.firstOrNull { node ->
            node.text?.toString()?.trim()?.equals(text, ignoreCase = true) == true
        } ?: return false
        return performClick(target)
    }

    private fun performClick(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
        }
        return false
    }

    private fun scrollChatList(root: AccessibilityNodeInfo) {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)

        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            if (node.isScrollable) {
                node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
                markAction()
                return
            }
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let(queue::add)
            }
        }
    }
}