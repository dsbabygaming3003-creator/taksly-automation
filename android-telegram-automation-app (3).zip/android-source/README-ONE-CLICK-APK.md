# One-click APK Download via GitHub

You do not need Android Studio for this. GitHub will build the APK for you in the cloud, and you download it with one click from your browser.

## Step 1 — Create a GitHub repository
1. Go to https://github.com/new
2. Name it (example: `taksly-automation`)
3. Keep it empty (no README/license), then click **Create repository**

## Step 2 — Upload this project to that repository
Option A — Using git commands (run in the project folder, the one containing `android-source/` and `.github/`):
```
git init
git add .
git commit -m "Taksly automation app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/taksly-automation.git
git push -u origin main
```

Option B — No terminal:
1. On the new GitHub repo page, click **uploading an existing file**
2. Drag the whole project folder (including `android-source/` and `.github/`) into the browser
3. Click **Commit changes**

## Step 3 — Build the APK (one click)
1. Open your repository on GitHub
2. Click the **Actions** tab
3. Click **Build Android APK** in the left list
4. Click **Run workflow** → **Run workflow** (green button)
5. Wait 3–6 minutes while it builds in the cloud

## Step 4 — Download the APK (one click)
1. Click on the finished workflow run (green check ✔)
2. Scroll down to **Artifacts**
3. Click **taksly-automation-debug-apk** — it downloads a `.zip`
4. Unzip it — inside is `app-debug.apk`
5. Send that APK to your phone and install it

## Optional — Public shareable download link
If you want a permanent link anyone can click to download (no GitHub login needed):
```
git tag v1.0.0
git push origin v1.0.0
```
GitHub will automatically create a **Release** with `app-debug.apk` attached. Share that Release page link — one click to download, no login required.

## Notes
- This workflow does **not** require you to generate a Gradle wrapper manually or open Android Studio — Gradle is installed automatically in the cloud build.
- If `Run workflow` button is not visible, make sure the workflow file `.github/workflows/build-android-apk.yml` was uploaded to the `main` branch.
- After installing the APK on your phone, open the app, tap **Open Accessibility Settings**, enable **Taksly Automation**, then return to the app — Telegram will open and the automation sequence runs: Taksly Bot → Tasks → Create Inst (2FA) → Start.
